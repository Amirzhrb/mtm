<?php
require __DIR__ . '/_bootstrap.php';
$type = q('type') ?: 'meta';
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
if (!preg_match('/^[A-Za-z0-9.:-]+$/', $host)) $host = 'localhost';
$origin = $scheme . '://' . $host;
$seo = get_setting('seo', ['title'=>'MTM Digital | ام تی ام دیجیتال','description'=>'فروشگاه محصولات دیجیتال','keywords'=>'MTM Digital']);
$store = get_setting('store', ['name_en'=>'MTM Digital','name_fa'=>'ام تی ام دیجیتال']);
if ($type === 'robots') {
  header('Content-Type: text/plain; charset=utf-8');
  echo "User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /checkout\nSitemap: {$origin}/api/seo?type=sitemap\n";
  exit;
}
if ($type === 'sitemap') {
  header('Content-Type: application/xml; charset=utf-8');
  echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
  echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
  $urls = [$origin.'/', $origin.'/products', $origin.'/blog'];
  foreach(read_table('categories') as $c) $urls[] = $origin.'/category/'.$c['slug'];
  foreach(read_table('products') as $p) $urls[] = $origin.'/product/'.$p['slug'];
  foreach(read_table('blog_posts') as $p) $urls[] = $origin.'/blog/'.$p['slug'];
  foreach(read_table('cms_pages') as $p) $urls[] = $origin.'/page/'.$p['slug'];
  foreach($urls as $u) echo '  <url><loc>' . htmlspecialchars($u, ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</loc><priority>0.8</priority></url>' . "\n";
  echo '</urlset>';
  exit;
}
respond(['seo'=>$seo,'store'=>$store,'title'=>$seo['title']??'','description'=>$seo['description']??'','keywords'=>$seo['keywords']??'']);
