<?php
require __DIR__ . '/_bootstrap.php';
$method=$_SERVER['REQUEST_METHOD'];
$rows=read_table('notifications');
if ($method==='GET'){
  $out=$rows;
  if(q('unread')==='true') $out=array_values(array_filter($out, fn($n)=>empty($n['read'])));
  usort($out, fn($a,$b)=>strcmp($b['created_at']??'',$a['created_at']??''));
  respond(array_slice($out,0,50));
}
$body=json_body();
if ($method==='POST'){ $body['id']=next_id($rows); if(empty($body['created_at'])) $body['created_at']=date('c'); $rows[]=$body; write_table('notifications',$rows); respond($body,201);} 
if ($method==='PUT'){
  if (!empty($body['mark_all_read'])) { foreach($rows as &$n) $n['read']=true; unset($n); write_table('notifications',$rows); respond(['ok'=>true]); }
  foreach($rows as &$r) if((string)$r['id']===(string)($body['id']??'')){ $r=array_merge($r,$body); write_table('notifications',$rows); respond($r);} 
  respond(['error'=>'not found'],404);
}
if ($method==='DELETE'){ $rows=array_values(array_filter($rows,fn($r)=>(string)$r['id']!==(string)($body['id']??''))); write_table('notifications',$rows); respond(['ok'=>true]); }
respond(['error'=>'Method not allowed'],405);
