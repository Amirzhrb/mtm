<?php
/**
 * MTM Digital API bootstrap.
 * The frontend and API are served from the same origin. Keep persistence in
 * JSON files for compatibility with standard PHP shared hosting.
 */

// UTF-8 JSON API; same-origin requests do not need wildcard CORS headers.
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('X-Frame-Options: SAMEORIGIN');

$httpsRequest = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
  || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
  || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');

if (session_status() !== PHP_SESSION_ACTIVE) {
  session_name('MTMDIGITALSESSID');
  session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => $httpsRequest,
    'httponly' => true,
    'samesite' => 'Lax',
  ]);
  session_start();
}

if (!function_exists('mb_strtolower')) {
  function mb_strtolower($value, $encoding = null) { return strtolower((string)$value); }
}
if (!function_exists('mb_strpos')) {
  function mb_strpos($haystack, $needle, $offset = 0, $encoding = null) {
    return strpos((string)$haystack, (string)$needle, (int)$offset);
  }
}

function data_dir() {
  $dir = dirname(__DIR__) . '/data';
  if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
    throw new RuntimeException('پوشه داده قابل ایجاد نیست. سطح دسترسی هاست را بررسی کنید.');
  }
  return $dir;
}

function read_table($name) {
  // Table names are always internal identifiers, never request parameters.
  if (!preg_match('/^[a-zA-Z0-9_-]+$/', (string)$name)) return [];
  $file = data_dir() . '/' . $name . '.json';
  if (!is_file($file)) return [];
  $raw = @file_get_contents($file);
  if ($raw === false || trim($raw) === '') return [];
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function write_table($name, $rows) {
  if (!preg_match('/^[a-zA-Z0-9_-]+$/', (string)$name)) {
    throw new InvalidArgumentException('نام جدول نامعتبر است.');
  }
  $dir = data_dir();
  $file = $dir . '/' . $name . '.json';
  $tmp = $file . '.' . bin2hex(random_bytes(5)) . '.tmp';
  $json = json_encode(array_values((array)$rows), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_INVALID_UTF8_SUBSTITUTE);
  if ($json === false) throw new RuntimeException('تبدیل اطلاعات به JSON ناموفق بود.');
  if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
    throw new RuntimeException('ذخیره اطلاعات ناموفق بود. سطح دسترسی پوشه data را بررسی کنید.');
  }
  @chmod($tmp, 0660);
  if (!@rename($tmp, $file)) {
    @unlink($tmp);
    throw new RuntimeException('ثبت اطلاعات روی سرور ناموفق بود.');
  }
  return true;
}

function json_body() {
  $raw = file_get_contents('php://input');
  if (!$raw) return [];
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function respond($data, $code = 200) {
  http_response_code((int)$code);
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
  $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
  echo $json === false ? '{"error":"خطا در ساخت پاسخ JSON"}' : $json;
  exit;
}

function acquire_store_lock() {
  $path = data_dir() . '/store.lock';
  $handle = @fopen($path, 'c');
  if (!$handle || !@flock($handle, LOCK_EX)) {
    if (is_resource($handle)) fclose($handle);
    respond(['error' => 'سرور در حال پردازش سفارش دیگری است. لطفاً دوباره تلاش کنید.'], 503);
  }
  return $handle; // PHP releases the lock automatically when the request ends.
}

set_exception_handler(function ($exception) {
  error_log('MTM Digital API exception: ' . (string)$exception);
  if (!headers_sent()) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
  }
  echo json_encode(['error' => 'خطای داخلی سرور رخ داد. لطفاً گزارش خطای هاست را بررسی کنید.'], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
  exit;
});

function q($key, $default = null) {
  return isset($_GET[$key]) ? $_GET[$key] : $default;
}

function next_id($rows) {
  $max = 0;
  foreach ((array)$rows as $r) if (isset($r['id']) && is_numeric($r['id']) && (int)$r['id'] > $max) $max = (int)$r['id'];
  return $max + 1;
}

function find_by($rows, $key, $value) {
  foreach ((array)$rows as $r) if (isset($r[$key]) && (string)$r[$key] === (string)$value) return $r;
  return null;
}

function current_user() {
  return isset($_SESSION['mtm_user']) && is_array($_SESSION['mtm_user']) ? $_SESSION['mtm_user'] : null;
}

function require_login() {
  $user = current_user();
  if (!$user) respond(['error' => 'برای انجام این کار ابتدا وارد حساب کاربری شوید.'], 401);
  return $user;
}

function require_admin() {
  $user = require_login();
  if (($user['role'] ?? 'customer') !== 'admin') {
    respond(['error' => 'دسترسی به این بخش فقط برای مدیر سایت مجاز است.'], 403);
  }
  return $user;
}

/** Central access rules keep the API and admin UI in sync. */
function enforce_api_access() {
  $file = basename($_SERVER['SCRIPT_NAME'] ?? '');
  $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

  $adminWrite = [
    'products.php', 'categories.php', 'banners.php', 'blog.php', 'pages.php',
    'coupons.php', 'settings.php', 'upload.php', 'notifications.php',
  ];
  if (in_array($file, $adminWrite, true) && $method !== 'GET') require_admin();

  if ($file === 'dashboard.php') require_admin();
  if ($file === 'notifications.php') require_admin();
  if ($file === 'upload.php') require_admin();

  if ($file === 'reviews.php' && in_array($method, ['PUT', 'DELETE'], true)) require_admin();
  if ($file === 'coupons.php' && $method === 'GET' && !q('code') && !q('validate')) require_admin();

  if ($file === 'orders.php') {
    if ($method === 'GET') {
      if (q('user_id') !== null && q('user_id') !== '') {
        $user = require_login();
        if (($user['role'] ?? '') !== 'admin' && (string)($user['id'] ?? '') !== (string)q('user_id')) {
          respond(['error' => 'دسترسی به سفارش‌های این حساب مجاز نیست.'], 403);
        }
      } else {
        require_admin();
      }
    } elseif (in_array($method, ['PUT', 'DELETE'], true)) {
      require_admin();
    }
  }

  if ($file === 'profiles.php') {
    if ($method === 'GET' && (q('id') || q('email'))) {
      $user = require_login();
      $requested = q('id') ?: q('email');
      $own = (string)($user['id'] ?? '') === (string)$requested || strcasecmp((string)($user['email'] ?? ''), (string)$requested) === 0;
      if (!$own && ($user['role'] ?? '') !== 'admin') respond(['error' => 'دسترسی به این پروفایل مجاز نیست.'], 403);
    } else {
      require_admin();
    }
  }
}

function unpack_product($p) {
  if (!$p) return $p;
  $gallery = $p['gallery'] ?? null;
  $images = []; $colors = []; $variants = [];
  $return_7_days = array_key_exists('return_7_days', $p) ? !empty($p['return_7_days']) : true;
  $wholesale = !empty($p['wholesale']);
  if (is_string($gallery)) {
    $decoded = json_decode($gallery, true);
    $gallery = $decoded !== null ? $decoded : ($gallery ? [$gallery] : []);
  }
  if (is_array($gallery)) {
    $isList = array_is_list($gallery);
    if ($isList) {
      $images = array_values(array_filter($gallery, 'is_string'));
    } else {
      $images = isset($gallery['images']) && is_array($gallery['images']) ? $gallery['images'] : [];
      $colors = isset($gallery['colors']) && is_array($gallery['colors']) ? $gallery['colors'] : [];
      $variants = isset($gallery['variants']) && is_array($gallery['variants']) ? $gallery['variants'] : [];
      if (array_key_exists('return_7_days', $gallery)) $return_7_days = !empty($gallery['return_7_days']);
      if (array_key_exists('wholesale', $gallery)) $wholesale = !empty($gallery['wholesale']);
    }
  }
  $p['gallery'] = array_slice(array_values(array_filter($images, 'is_string')), 0, 5);
  $p['colors'] = $colors;
  $p['variants'] = $variants;
  $p['return_7_days'] = $return_7_days;
  $p['wholesale'] = $wholesale;
  if (empty($p['image_url']) && !empty($p['gallery'][0])) $p['image_url'] = $p['gallery'][0];
  return $p;
}

function pack_product($body) {
  $images = [];
  if (isset($body['gallery']) && is_array($body['gallery'])) {
    $g = $body['gallery'];
    if (array_is_list($g)) $images = array_slice(array_values(array_filter($g, 'is_string')), 0, 5);
    elseif (isset($g['images']) && is_array($g['images'])) $images = array_slice(array_values(array_filter($g['images'], 'is_string')), 0, 5);
  } elseif (!empty($body['image_url'])) $images = [$body['image_url']];
  $colors = isset($body['colors']) && is_array($body['colors']) ? $body['colors'] : [];
  $variants = isset($body['variants']) && is_array($body['variants']) ? $body['variants'] : [];
  $specs = $body['specs'] ?? new stdClass();
  if (is_array($specs) && isset($specs[0]) && is_array($specs[0])) {
    $obj = [];
    foreach ($specs as $row) if (!empty($row['key'])) $obj[$row['key']] = $row['value'] ?? '';
    $specs = $obj;
  }
  $return_7_days = array_key_exists('return_7_days', $body) ? !empty($body['return_7_days']) : true;
  $wholesale = !empty($body['wholesale']);
  return [
    'name' => trim((string)($body['name'] ?? '')),
    'slug' => trim((string)($body['slug'] ?? '')),
    'description' => (string)($body['description'] ?? ''),
    'short_description' => (string)($body['short_description'] ?? ''),
    'price' => max(0, (int)($body['price'] ?? 0)),
    'sale_price' => !empty($body['sale_price']) ? max(0, (int)$body['sale_price']) : null,
    'sku' => trim((string)($body['sku'] ?? '')),
    'stock' => max(0, (int)($body['stock'] ?? 0)),
    'image_url' => (string)($body['image_url'] ?? ($images[0] ?? '')),
    'gallery' => ['images'=>$images,'colors'=>$colors,'variants'=>$variants,'return_7_days'=>$return_7_days,'wholesale'=>$wholesale],
    'category_id' => isset($body['category_id']) && $body['category_id'] !== '' ? (int)$body['category_id'] : null,
    'featured' => !empty($body['featured']),
    'bestseller' => !empty($body['bestseller']),
    'brand' => trim((string)($body['brand'] ?? '')),
    'return_7_days' => $return_7_days,
    'wholesale' => $wholesale,
    'specs' => $specs ?: new stdClass(),
    'seo_title' => (string)($body['seo_title'] ?? ''),
    'seo_description' => (string)($body['seo_description'] ?? ''),
  ];
}

function attach_categories($products) {
  $cats = read_table('categories');
  $map = [];
  foreach ($cats as $c) if (isset($c['id'])) $map[(int)$c['id']] = ['id'=>$c['id'],'name'=>$c['name'] ?? '', 'slug'=>$c['slug'] ?? ''];
  $out = [];
  foreach ((array)$products as $p) {
    $p = unpack_product($p);
    $cid = isset($p['category_id']) ? (int)$p['category_id'] : 0;
    $p['categories'] = $cid && isset($map[$cid]) ? $map[$cid] : null;
    $out[] = $p;
  }
  return $out;
}

function get_setting($key, $defaults = []) {
  $rows = read_table('store_settings');
  foreach ($rows as $r) {
    if (($r['key'] ?? '') === $key) {
      $val = $r['value'] ?? [];
      if (!is_array($val)) $val = [];
      return array_merge($defaults, $val);
    }
  }
  return $defaults;
}

function set_setting($key, $value) {
  $rows = read_table('store_settings');
  $found = false;
  foreach ($rows as &$r) {
    if (($r['key'] ?? '') === $key) {
      $r['value'] = $value;
      $r['updated_at'] = date('c');
      $found = true;
      break;
    }
  }
  unset($r);
  if (!$found) $rows[] = ['id' => next_id($rows), 'key' => $key, 'value' => $value, 'updated_at' => date('c')];
  write_table('store_settings', $rows);
  return $value;
}

enforce_api_access();
