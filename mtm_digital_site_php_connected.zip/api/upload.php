<?php
require __DIR__ . '/_bootstrap.php';
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

function uploads_root() {
  $dir = dirname(__DIR__) . '/uploads/products';
  if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) respond(['error' => 'پوشه آپلود قابل ایجاد نیست.'], 500);
  return $dir;
}

function safe_upload_target($input) {
  $s = str_replace('\\', '/', (string)$input);
  if (strpos($s, '/uploads/products/') !== false) $s = substr($s, strpos($s, '/uploads/products/') + strlen('/uploads/products/'));
  elseif (strpos($s, 'products/') === 0) $s = substr($s, strlen('products/'));
  if ($s === '' || basename($s) !== $s || strpos($s, '..') !== false) return null;
  return uploads_root() . '/' . $s;
}

if ($method === 'POST') {
  $body = json_body();
  $base64 = (string)($body['fileBase64'] ?? '');
  if ($base64 === '') respond(['error' => 'فایل نامعتبر است.'], 400);
  // Accept either raw base64 or a data URI, but validate actual image content.
  if (strpos($base64, ',') !== false && str_starts_with($base64, 'data:')) $base64 = substr($base64, strpos($base64, ',') + 1);
  $bin = base64_decode($base64, true);
  if ($bin === false || $bin === '') respond(['error' => 'داده تصویر نامعتبر است.'], 400);
  if (strlen($bin) > 5 * 1024 * 1024) respond(['error' => 'حجم تصویر نباید بیشتر از ۵ مگابایت باشد.'], 413);

  $mime = '';
  if (function_exists('finfo_open')) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo) { $mime = (string)finfo_buffer($finfo, $bin); finfo_close($finfo); }
  }
  $allowed = ['image/jpeg'=>'jpg', 'image/png'=>'png', 'image/webp'=>'webp', 'image/gif'=>'gif'];
  if (!isset($allowed[$mime])) respond(['error' => 'فقط تصویر JPG، PNG، WEBP یا GIF قابل آپلود است.'], 415);
  if (function_exists('getimagesizefromstring') && @getimagesizefromstring($bin) === false) respond(['error' => 'محتوای فایل، تصویر معتبر نیست.'], 415);

  $name = bin2hex(random_bytes(10)) . '.' . $allowed[$mime];
  $target = uploads_root() . '/' . $name;
  if (@file_put_contents($target, $bin, LOCK_EX) === false) respond(['error' => 'ذخیره تصویر روی سرور ناموفق بود.'], 500);
  @chmod($target, 0644);
  respond(['url' => '/uploads/products/' . $name, 'path' => 'products/' . $name, 'mime' => $mime, 'size' => strlen($bin)], 201);
}

if ($method === 'DELETE') {
  $body = json_body();
  $target = safe_upload_target($body['path'] ?? ($body['url'] ?? ''));
  if (!$target || !is_file($target)) respond(['ok' => true, 'skipped' => true]);
  $root = realpath(uploads_root());
  $real = realpath($target);
  if (!$root || !$real || !str_starts_with($real, $root . DIRECTORY_SEPARATOR)) respond(['error' => 'مسیر فایل نامعتبر است.'], 400);
  respond(['ok' => @unlink($real), 'deleted' => !file_exists($real)]);
}

respond(['error' => 'Method not allowed'], 405);
