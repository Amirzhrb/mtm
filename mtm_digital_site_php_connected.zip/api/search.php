<?php
require __DIR__ . '/_bootstrap.php';
$q=trim((string)(q('q')??''));
if ($q==='') respond(['products'=>[],'categories'=>[]]);
$t=mb_strtolower($q);
$products=[];
foreach(read_table('products') as $p){
  $hay=mb_strtolower(($p['name']??'').' '.($p['description']??'').' '.($p['sku']??''));
  if(mb_strpos($hay,$t)!==false) $products[]=['id'=>$p['id'],'name'=>$p['name'],'slug'=>$p['slug'],'price'=>$p['price'],'sale_price'=>$p['sale_price']??null,'image_url'=>$p['image_url']??'','stock'=>$p['stock']??0];
  if(count($products)>=8) break;
}
$categories=[];
foreach(read_table('categories') as $c){
  $hay=mb_strtolower(($c['name']??'').' '.($c['description']??''));
  if(mb_strpos($hay,$t)!==false) $categories[]=['id'=>$c['id'],'name'=>$c['name'],'slug'=>$c['slug'],'image_url'=>$c['image_url']??''];
  if(count($categories)>=5) break;
}
respond(['products'=>$products,'categories'=>$categories]);
