<?php
require __DIR__ . '/_bootstrap.php';
$method = $_SERVER['REQUEST_METHOD'];
$rows = read_table('products');

if ($method === 'GET') {
  header('Cache-Control: public, max-age=15, s-maxage=30, stale-while-revalidate=120');

  if ($id = q('id')) {
    $p = find_by($rows, 'id', $id);
    if (!$p) respond(['error' => 'not found'], 404);
    respond(attach_categories([$p])[0]);
  }
  if ($slug = q('slug')) {
    $p = find_by($rows, 'slug', $slug);
    if (!$p) respond(['error' => 'not found'], 404);
    respond(attach_categories([$p])[0]);
  }

  $out = $rows;
  if (q('category_id') !== null && q('category_id') !== '') {
    $out = array_values(array_filter($out, fn($p) => (string)($p['category_id'] ?? '') === (string)q('category_id')));
  }
  if (q('featured') === 'true') $out = array_values(array_filter($out, fn($p) => !empty($p['featured'])));
  if (q('bestseller') === 'true') $out = array_values(array_filter($out, fn($p) => !empty($p['bestseller'])));
  if (q('on_sale') === 'true') $out = array_values(array_filter($out, fn($p) => !empty($p['sale_price']) && $p['sale_price'] > 0));

  $term = q('search') ?: q('q');
  if ($term) {
    $t = mb_strtolower($term);
    $out = array_values(array_filter($out, function ($p) use ($t) {
      $hay = mb_strtolower(($p['name'] ?? '') . ' ' . ($p['description'] ?? '') . ' ' . ($p['sku'] ?? ''));
      return mb_strpos($hay, $t) !== false;
    }));
  }

  $sort = q('sort');
  if ($sort === 'price_asc') usort($out, fn($a, $b) => ($a['price'] ?? 0) <=> ($b['price'] ?? 0));
  elseif ($sort === 'price_desc') usort($out, fn($a, $b) => ($b['price'] ?? 0) <=> ($a['price'] ?? 0));
  elseif ($sort === 'newest') usort($out, fn($a, $b) => strcmp($b['created_at'] ?? '', $a['created_at'] ?? ''));
  else usort($out, fn($a, $b) => ($a['id'] ?? 0) <=> ($b['id'] ?? 0));

  if ($limit = q('limit')) $out = array_slice($out, 0, (int)$limit);

  // List endpoints: lighter payload (unless full=1)
  $full = q('full') === '1';
  if (!$full) {
    $out = array_map(function ($p) {
      $p = unpack_product($p);
      return [
        'id' => $p['id'] ?? null,
        'name' => $p['name'] ?? '',
        'slug' => $p['slug'] ?? '',
        'price' => $p['price'] ?? 0,
        'sale_price' => $p['sale_price'] ?? null,
        'image_url' => $p['image_url'] ?? '',
        'gallery' => array_slice($p['gallery'] ?? [], 0, 2),
        'stock' => $p['stock'] ?? 0,
        'featured' => !empty($p['featured']),
        'bestseller' => !empty($p['bestseller']),
        'category_id' => $p['category_id'] ?? null,
        'brand' => $p['brand'] ?? '',
        'short_description' => $p['short_description'] ?? '',
        'sku' => $p['sku'] ?? '',
        'return_7_days' => !empty($p['return_7_days']),
        'wholesale' => !empty($p['wholesale']),
        'created_at' => $p['created_at'] ?? null,
      ];
    }, $out);
  }

  respond(attach_categories($out));
}

$body = json_body();
if ($method === 'POST') {
  $payload = pack_product($body);
  $payload['id'] = next_id($rows);
  $payload['created_at'] = date('c');
  $rows[] = $payload;
  write_table('products', $rows);
  respond(attach_categories([$payload])[0], 201);
}
if ($method === 'PUT') {
  $id = $body['id'] ?? null;
  foreach ($rows as &$r) {
    if ((string)$r['id'] === (string)$id) {
      $payload = pack_product($body);
      $payload['id'] = $r['id'];
      $payload['created_at'] = $r['created_at'] ?? date('c');
      $r = $payload;
      write_table('products', $rows);
      respond(attach_categories([$r])[0]);
    }
  }
  respond(['error' => 'not found'], 404);
}
if ($method === 'DELETE') {
  $rows = array_values(array_filter($rows, fn($r) => (string)$r['id'] !== (string)($body['id'] ?? '')));
  write_table('products', $rows);
  respond(['ok' => true]);
}
respond(['error' => 'Method not allowed'], 405);
