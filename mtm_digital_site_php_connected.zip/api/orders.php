<?php
require __DIR__ . '/_bootstrap.php';
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$rows = read_table('orders');

if ($method === 'GET') {
  if ($id = q('id')) {
    $order = find_by($rows, 'id', $id);
    respond($order ?: ['error' => 'سفارش یافت نشد.'], $order ? 200 : 404);
  }
  $out = $rows;
  if ($uid = q('user_id')) $out = array_values(array_filter($out, fn($o) => (string)($o['user_id'] ?? '') === (string)$uid));
  if ($status = q('status')) $out = array_values(array_filter($out, fn($o) => ($o['status'] ?? '') === $status));
  usort($out, fn($a, $b) => strcmp($b['created_at'] ?? '', $a['created_at'] ?? ''));
  respond($out);
}

$body = json_body();
if ($method === 'POST') {
  $storeLock = acquire_store_lock();
  $rows = read_table('orders');
  $name = trim((string)($body['customer_name'] ?? ''));
  $email = strtolower(trim((string)($body['customer_email'] ?? '')));
  $phoneRaw = strtr((string)($body['customer_phone'] ?? ''), ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
  $phone = preg_replace('/[^0-9+]/', '', $phoneRaw);
  $address = trim((string)($body['address'] ?? ''));
  $city = trim((string)($body['city'] ?? ''));
  $postal = trim((string)($body['postal_code'] ?? ''));
  $itemsIn = $body['items'] ?? null;
  if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($phone) < 8 || $address === '' || $city === '') {
    respond(['error' => 'نام، ایمیل معتبر، شماره تماس، شهر و نشانی کامل الزامی است.'], 400);
  }
  if (!is_array($itemsIn) || count($itemsIn) < 1 || count($itemsIn) > 40) {
    respond(['error' => 'سبد خرید نامعتبر است.'], 400);
  }

  $products = read_table('products');
  $productsById = [];
  foreach ($products as $product) $productsById[(string)($product['id'] ?? '')] = unpack_product($product);

  $items = [];
  $subtotal = 0;
  $stockNeeds = [];
  foreach ($itemsIn as $item) {
    if (!is_array($item)) respond(['error' => 'یکی از اقلام سبد خرید نامعتبر است.'], 400);
    $productId = (string)($item['product_id'] ?? '');
    $quantity = (int)($item['quantity'] ?? 0);
    if ($productId === '' || $quantity < 1 || $quantity > 99 || !isset($productsById[$productId])) {
      respond(['error' => 'یکی از محصولات سبد خرید معتبر نیست.'], 400);
    }
    $product = $productsById[$productId];
    $available = max(0, (int)($product['stock'] ?? 0));
    $stockNeeds[$productId] = ($stockNeeds[$productId] ?? 0) + $quantity;
    if ($stockNeeds[$productId] > $available) {
      respond(['error' => 'موجودی محصول «' . (string)($product['name'] ?? '') . '» کافی نیست.'], 409);
    }

    $basePrice = (int)($product['price'] ?? 0);
    $salePrice = (int)($product['sale_price'] ?? 0);
    $unitPrice = ($salePrice > 0 && $salePrice < $basePrice) ? $salePrice : $basePrice;
    $variantLabel = trim((string)($item['variant_label'] ?? ''));

    // Variant group price_delta is server-owned. Match the selected options sent by the UI.
    if (!empty($product['variants']) && is_array($product['variants'])) {
      $selected = [];
      foreach (preg_split('/\s*\/\s*/u', $variantLabel) as $part) {
        $pair = explode(':', $part, 2);
        if (count($pair) === 2) $selected[trim($pair[0])] = trim($pair[1]);
      }
      foreach ($product['variants'] as $variant) {
        $groupName = trim((string)($variant['name'] ?? ''));
        $options = is_array($variant['options'] ?? null) ? $variant['options'] : [];
        if ($groupName === '') continue;
        if (!isset($selected[$groupName]) || !in_array($selected[$groupName], array_map('strval', $options), true)) {
          respond(['error' => 'لطفاً تنوع محصول «' . (string)($product['name'] ?? '') . '» را دوباره انتخاب کنید.'], 409);
        }
        $unitPrice += (int)($variant['price_delta'] ?? 0);
      }
    }
    if ($unitPrice < 0) $unitPrice = 0;
    $subtotal += $unitPrice * $quantity;
    $items[] = [
      'product_id' => $productId,
      'name' => (string)($product['name'] ?? ''),
      'slug' => (string)($product['slug'] ?? ''),
      'image_url' => (string)($product['image_url'] ?? ''),
      'price' => $unitPrice,
      'quantity' => $quantity,
      'stock' => $available,
      'color' => (string)($item['color'] ?? ''),
      'color_hex' => (string)($item['color_hex'] ?? ''),
      'variant_label' => $variantLabel,
      'line_key' => (string)($item['line_key'] ?? ''),
    ];
  }

  // Validate and calculate coupon discount on the server.
  $discount = 0;
  $discountCode = strtoupper(trim((string)($body['discount_code'] ?? '')));
  $coupons = read_table('coupons');
  $couponIndex = null;
  if ($discountCode !== '') {
    foreach ($coupons as $i => $coupon) {
      if (strtoupper((string)($coupon['code'] ?? '')) !== $discountCode) continue;
      $couponIndex = $i;
      break;
    }
    if ($couponIndex === null || empty($coupons[$couponIndex]['active'])) {
      respond(['error' => 'کد تخفیف معتبر نیست.'], 400);
    }
    $coupon = $coupons[$couponIndex];
    if (!empty($coupon['expires_at']) && strtotime((string)$coupon['expires_at']) < time()) respond(['error' => 'کد تخفیف منقضی شده است.'], 400);
    if (!empty($coupon['max_uses']) && (int)($coupon['used_count'] ?? 0) >= (int)$coupon['max_uses']) respond(['error' => 'ظرفیت استفاده از کد تکمیل شده است.'], 400);
    if (!empty($coupon['min_order']) && $subtotal < (int)$coupon['min_order']) respond(['error' => 'حداقل مبلغ سفارش برای این کد رعایت نشده است.'], 400);
    $value = max(0, (int)($coupon['value'] ?? 0));
    $discount = ($coupon['type'] ?? '') === 'percent'
      ? (int)round($subtotal * min(100, $value) / 100)
      : $value;
    $discount = min($subtotal, $discount);
  }

  // Shipping is also derived from the saved admin shipping settings.
  $shippingKey = get_setting('shipping_methods', ['methods' => [
    ['id'=>'standard','name'=>'ارسال عادی','price'=>65000,'active'=>true],
    ['id'=>'express','name'=>'ارسال سریع','price'=>120000,'active'=>true],
  ]]);
  $methods = is_array($shippingKey['methods'] ?? null) ? $shippingKey['methods'] : [];
  $shippingId = (string)($body['shipping_method_id'] ?? '');
  $shippingMethod = null;
  foreach ($methods as $sm) if ((string)($sm['id'] ?? '') === $shippingId && !empty($sm['active'])) { $shippingMethod = $sm; break; }
  if ($shippingMethod) {
    $shipping = max(0, (int)($shippingMethod['price'] ?? 0));
    $shippingName = (string)($shippingMethod['name'] ?? '');
  } else {
    $store = get_setting('store', ['shipping_cost'=>65000]);
    $shipping = max(0, (int)($store['shipping_cost'] ?? 65000));
    $shippingName = trim((string)($body['shipping_method'] ?? 'ارسال عادی'));
  }
  $store = get_setting('store', ['free_shipping_min'=>2000000]);
  $freeMinimum = (int)($store['free_shipping_min'] ?? 0);
  if ($freeMinimum > 0 && $subtotal >= $freeMinimum) $shipping = 0;

  $total = max(0, $subtotal - $discount + $shipping);
  if ($total < 1000) respond(['error' => 'مبلغ نهایی سفارش نامعتبر است.'], 400);

  // Decrease inventory only after all order checks have passed.
  foreach ($products as &$product) {
    $pid = (string)($product['id'] ?? '');
    if (isset($stockNeeds[$pid])) $product['stock'] = max(0, (int)($product['stock'] ?? 0) - $stockNeeds[$pid]);
  }
  unset($product);
  write_table('products', $products);

  if ($couponIndex !== null) {
    $coupons[$couponIndex]['used_count'] = (int)($coupons[$couponIndex]['used_count'] ?? 0) + 1;
    write_table('coupons', $coupons);
  }

  $user = current_user();
  $orderNumber = 'MTM-' . strtoupper(bin2hex(random_bytes(4)));
  $order = [
    'id' => next_id($rows),
    'order_number' => $orderNumber,
    'user_id' => $user['id'] ?? null,
    'customer_name' => $name,
    'customer_email' => $email,
    'customer_phone' => $phone,
    'address' => $address,
    'city' => $city,
    'postal_code' => $postal,
    'status' => 'pending',
    'payment_status' => 'pending',
    'payment_method' => (string)($body['payment_method'] ?? 'online'),
    'subtotal' => $subtotal,
    'discount_code' => $discountCode !== '' ? $discountCode : null,
    'discount_amount' => $discount,
    'shipping' => $shipping,
    'shipping_method' => $shippingName,
    'shipping_method_id' => $shippingId,
    'total' => $total,
    'items' => $items,
    'notes' => substr(trim((string)($body['notes'] ?? '')), 0, 2000),
    'created_at' => date('c'),
  ];
  $rows[] = $order;
  write_table('orders', $rows);

  $notifications = read_table('notifications');
  $notifications[] = [
    'id' => next_id($notifications), 'title' => 'سفارش جدید',
    'message' => "سفارش $orderNumber ثبت شد", 'type' => 'order',
    'read' => false, 'created_at' => date('c'),
  ];
  write_table('notifications', $notifications);
  respond($order, 201);
}

if ($method === 'PUT') {
  foreach ($rows as &$row) {
    if ((string)($row['id'] ?? '') === (string)($body['id'] ?? '')) {
      $allowed = ['status'];
      foreach ($allowed as $field) if (array_key_exists($field, $body)) $row[$field] = $body[$field];
      $row['updated_at'] = date('c');
      write_table('orders', $rows);
      respond($row);
    }
  }
  respond(['error' => 'سفارش یافت نشد.'], 404);
}

if ($method === 'DELETE') {
  $rows = array_values(array_filter($rows, fn($r) => (string)($r['id'] ?? '') !== (string)($body['id'] ?? '')));
  write_table('orders', $rows);
  respond(['ok' => true]);
}

respond(['error' => 'Method not allowed'], 405);
