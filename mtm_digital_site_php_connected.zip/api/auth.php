<?php
require __DIR__ . '/_bootstrap.php';
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$usersFile = data_dir() . '/users.json';

function save_users($users) {
  $path = data_dir() . '/users.json';
  $json = json_encode(array_values($users), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_INVALID_UTF8_SUBSTITUTE);
  if ($json === false || @file_put_contents($path, $json, LOCK_EX) === false) {
    respond(['error' => 'ذخیره اطلاعات حساب کاربری ناموفق بود.'], 500);
  }
  @chmod($path, 0660);
}

function public_user($u) {
  return [
    'id' => (string)($u['id'] ?? ''),
    'email' => (string)($u['email'] ?? ''),
    'full_name' => (string)($u['full_name'] ?? ''),
    'role' => (string)($u['role'] ?? 'customer'),
    'phone' => (string)($u['phone'] ?? ''),
  ];
}

function login_payload($u) {
  // Store only the minimum identity and role in the server-side session.
  $safe = public_user($u);
  session_regenerate_id(true);
  $_SESSION['mtm_user'] = $safe;
  $_SESSION['mtm_login_at'] = time();

  $profiles = read_table('profiles');
  $found = false;
  foreach ($profiles as &$p) {
    if ((string)($p['id'] ?? '') === $safe['id'] || strcasecmp((string)($p['email'] ?? ''), $safe['email']) === 0) {
      $p = array_merge($p, $safe);
      $found = true;
      break;
    }
  }
  unset($p);
  if (!$found) $profiles[] = $safe + ['created_at' => date('c')];
  write_table('profiles', $profiles);

  return [
    'ok' => true,
    'user' => [
      'id' => $safe['id'],
      'email' => $safe['email'],
      'user_metadata' => ['full_name' => $safe['full_name']],
      'app_metadata' => ['provider' => 'php', 'role' => $safe['role']],
      'aud' => 'authenticated',
      'role' => 'authenticated',
    ],
    'profile' => $safe,
    'session' => ['user' => ['id'=>$safe['id'], 'email'=>$safe['email']], 'access_token' => 'php-session'],
    'token' => 'php-session',
    'access_token' => 'php-session',
    'mode' => 'php',
    'message' => 'ورود موفق',
  ];
}

$users = [];
if (is_file($usersFile)) {
  $decoded = json_decode((string)file_get_contents($usersFile), true);
  if (is_array($decoded)) $users = $decoded;
}

// First-install administrator. Change this password immediately after first login.
if (!$users) {
  $users[] = [
    'id' => 'admin-local-1',
    'email' => 'admin@mtmdigital.ir',
    'password' => password_hash('admin123456', PASSWORD_DEFAULT),
    'full_name' => 'مدیر MTM Digital',
    'role' => 'admin',
    'created_at' => date('c'),
  ];
  save_users($users);
}

if ($method === 'GET') {
  $user = current_user();
  respond(['ok' => true, 'mode' => 'php', 'authenticated' => (bool)$user, 'user' => $user ? public_user($user) : null]);
}

if ($method !== 'POST') respond(['error' => 'Method not allowed'], 405);
$body = json_body();
$action = strtolower(trim((string)($body['action'] ?? 'login')));

if ($action === 'logout') {
  $_SESSION = [];
  if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'] ?? '/', $params['domain'] ?? '', !empty($params['secure']), !empty($params['httponly']));
  }
  session_destroy();
  respond(['ok' => true, 'message' => 'خروج انجام شد']);
}

if ($action === 'change_password') {
  $sessionUser = require_login();
  $currentPassword = (string)($body['current_password'] ?? '');
  $newPassword = (string)($body['new_password'] ?? '');
  if (strlen($newPassword) < 10) {
    respond(['error' => 'رمز جدید باید حداقل ۱۰ کاراکتر باشد.'], 400);
  }
  if ($currentPassword === '') respond(['error' => 'رمز فعلی را وارد کنید.'], 400);
  $found = false;
  foreach ($users as $index => $candidate) {
    if ((string)($candidate['id'] ?? '') !== (string)($sessionUser['id'] ?? '')) continue;
    $stored = (string)($candidate['password'] ?? '');
    $verified = password_verify($currentPassword, $stored);
    if (!$verified && $stored !== '' && !str_starts_with($stored, '$2y$') && hash_equals($stored, $currentPassword)) $verified = true;
    if (!$verified) respond(['error' => 'رمز فعلی صحیح نیست.'], 401);
    $users[$index]['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
    save_users($users);
    $found = true;
    break;
  }
  if (!$found) respond(['error' => 'حساب کاربری پیدا نشد.'], 404);
  respond(['ok' => true, 'message' => 'رمز عبور با موفقیت تغییر کرد.']);
}

$email = strtolower(trim((string)($body['email'] ?? '')));
$password = (string)($body['password'] ?? '');
$fullName = trim((string)($body['full_name'] ?? ''));

if ($action === 'login') {
  if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
    respond(['error' => 'ایمیل یا رمز عبور نادرست است.'], 401);
  }
  foreach ($users as $index => $u) {
    if (strtolower((string)($u['email'] ?? '')) !== $email) continue;
    $stored = (string)($u['password'] ?? '');
    $valid = password_verify($password, $stored);
    // One-time upgrade for installations that still store old plaintext passwords.
    if (!$valid && $stored !== '' && !str_starts_with($stored, '$2y$') && hash_equals($stored, $password)) {
      $valid = true;
      $users[$index]['password'] = password_hash($password, PASSWORD_DEFAULT);
      save_users($users);
    }
    if ($valid) respond(login_payload($users[$index]));
    break;
  }
  respond(['error' => 'ایمیل یا رمز عبور نادرست است.'], 401);
}

if ($action === 'signup') {
  if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8 || $fullName === '') {
    respond(['error' => 'نام، ایمیل معتبر و رمز عبور حداقل ۸ کاراکتری الزامی است.'], 400);
  }
  foreach ($users as $u) {
    if (strtolower((string)($u['email'] ?? '')) === $email) respond(['error' => 'این ایمیل قبلاً ثبت شده است.'], 409);
  }
  $user = [
    'id' => 'user-' . bin2hex(random_bytes(8)),
    'email' => $email,
    'password' => password_hash($password, PASSWORD_DEFAULT),
    'full_name' => $fullName,
    'role' => 'customer',
    'created_at' => date('c'),
  ];
  $users[] = $user;
  save_users($users);
  respond(login_payload($user), 201);
}

respond(['error' => 'عملیات احراز هویت نامعتبر است.'], 400);
