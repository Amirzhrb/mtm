<?php
require __DIR__ . '/_bootstrap.php';
$lim=(int)(q('limit')?:8);
$products=read_table('products');
$pid=q('product_id'); $cid=q('category_id');
$out=[];
if ($pid) {
  $cur=find_by($products,'id',$pid);
  if ($cur) {
    $out=array_values(array_filter($products, fn($p)=>($p['category_id']??null)==($cur['category_id']??null) && (string)$p['id']!==(string)$pid));
    $out=array_slice($out,0,$lim);
  }
} elseif ($cid) {
  $out=array_slice(array_values(array_filter($products, fn($p)=>(string)($p['category_id']??'')===(string)$cid && !empty($p['bestseller']))),0,$lim);
} else {
  $out=array_slice(array_values(array_filter($products, fn($p)=>!empty($p['bestseller'])||!empty($p['featured']))),0,$lim);
}
respond(attach_categories($out));
