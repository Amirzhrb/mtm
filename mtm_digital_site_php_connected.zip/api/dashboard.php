<?php
require __DIR__ . '/_bootstrap.php';
$products = read_table('products');
$orders = read_table('orders');
usort($orders, fn($a,$b)=>strcmp($b['created_at']??'',$a['created_at']??''));
$profiles = read_table('profiles');
$low = array_values(array_filter($products, fn($p)=>($p['stock']??0)<10));
usort($low, fn($a,$b)=>($a['stock']??0)<=>($b['stock']??0));
$coupons = read_table('coupons');
$reviews = read_table('reviews');
$totalRevenue = 0;
foreach ($orders as $o) {
  if (($o['payment_status']??'')==='paid' || in_array($o['status']??'', ['delivered','shipped'], true)) $totalRevenue += (int)($o['total']??0);
}
$statusCounts = [];
foreach ($orders as $o) { $s=$o['status']??'pending'; $statusCounts[$s]=($statusCounts[$s]??0)+1; }
$days=[];
for ($i=6;$i>=0;$i--){
  $d=date('Y-m-d', strtotime("-$i days"));
  $dayOrders=array_values(array_filter($orders, fn($o)=>str_starts_with((string)($o['created_at']??''),$d)));
  $rev=0; foreach($dayOrders as $o)$rev+=(int)($o['total']??0);
  $days[]=['date'=>$d,'label'=>$d,'orders'=>count($dayOrders),'revenue'=>$rev];
}
$top=[];
foreach($orders as $o){ foreach(($o['items']??[]) as $item){ $k=$item['name']??($item['product_id']??'x'); if(!isset($top[$k])) $top[$k]=['name'=>$item['name']??'','qty'=>0,'revenue'=>0]; $top[$k]['qty']+=(int)($item['quantity']??1); $top[$k]['revenue']+=((int)($item['price']??0))*((int)($item['quantity']??1)); }}
usort($top, fn($a,$b)=>$b['qty']<=>$a['qty']);
$avg = count($reviews)? round(array_sum(array_map(fn($r)=>(int)($r['rating']??0),$reviews))/max(1,count($reviews)),1):0;
respond([
  'stats'=>[
    'totalProducts'=>count($products),'totalOrders'=>count($orders),'totalRevenue'=>$totalRevenue,
    'pendingOrders'=>count(array_filter($orders, fn($o)=>($o['status']??'')==='pending')),
    'customers'=>count($profiles),'lowStockCount'=>count($low),
    'activeCoupons'=>count(array_filter($coupons, fn($c)=>!empty($c['active']))),
    'avgRating'=>$avg,'totalStock'=>array_sum(array_map(fn($p)=>(int)($p['stock']??0),$products)),
  ],
  'statusCounts'=>$statusCounts,'recentOrders'=>array_slice($orders,0,8),'lowStock'=>array_slice($low,0,10),
  'salesChart'=>$days,'bestsellers'=>array_slice(array_values($top),0,5),
]);
