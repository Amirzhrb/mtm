<?php
require __DIR__ . '/_bootstrap.php';

// Cache homepage payload briefly on reverse proxies / browsers
header('Cache-Control: public, max-age=30, s-maxage=60, stale-while-revalidate=300');

$banners = array_values(array_filter(read_table('banners'), fn($b) => !empty($b['active'])));
usort($banners, fn($a, $b) => ($a['sort_order'] ?? 0) <=> ($b['sort_order'] ?? 0));
$cats = read_table('categories');
usort($cats, fn($a, $b) => ($a['sort_order'] ?? 0) <=> ($b['sort_order'] ?? 0));

// Lightweight product projection for homepage speed
$rawProducts = read_table('products');
usort($rawProducts, fn($a, $b) => ($a['id'] ?? 0) <=> ($b['id'] ?? 0));
$products = attach_categories(array_map(function ($p) {
  $p = unpack_product($p);
  return [
    'id' => $p['id'] ?? null,
    'name' => $p['name'] ?? '',
    'slug' => $p['slug'] ?? '',
    'price' => $p['price'] ?? 0,
    'sale_price' => $p['sale_price'] ?? null,
    'image_url' => $p['image_url'] ?? '',
    'gallery' => array_slice($p['gallery'] ?? [], 0, 2),
    'stock' => $p['stock'] ?? 0,
    'featured' => !empty($p['featured']),
    'bestseller' => !empty($p['bestseller']),
    'category_id' => $p['category_id'] ?? null,
    'brand' => $p['brand'] ?? '',
    'short_description' => $p['short_description'] ?? '',
    'return_7_days' => !empty($p['return_7_days']),
    'wholesale' => !empty($p['wholesale']),
    'categories' => $p['categories'] ?? null,
  ];
}, $rawProducts));

$reviews = array_values(array_filter(read_table('reviews'), fn($r) => !isset($r['approved']) || $r['approved']));
$featured = array_values(array_filter($products, fn($p) => !empty($p['featured'])));
$best = array_values(array_filter($products, fn($p) => !empty($p['bestseller'])));
$sale = array_values(array_filter($products, fn($p) => !empty($p['sale_price']) && $p['sale_price'] < ($p['price'] ?? 0)));

respond([
  'heroes' => array_values(array_filter($banners, fn($b) => ($b['type'] ?? '') === 'hero')),
  'promoBanners' => array_values(array_filter($banners, fn($b) => ($b['type'] ?? '') === 'promo')),
  'categories' => $cats,
  'featured' => array_slice($featured ?: $products, 0, 8),
  'bestsellers' => array_slice($best ?: $products, 0, 8),
  'onSale' => array_slice($sale ?: array_values(array_filter($products, fn($p) => !empty($p['sale_price']))), 0, 8),
  'reviews' => array_slice($reviews, 0, 6),
  'allProducts' => array_slice($products, 0, 8),
]);
