<?php
require __DIR__ . '/_bootstrap.php';
$method=$_SERVER['REQUEST_METHOD'];
$rows=read_table('profiles');
if ($method==='GET'){
  if ($id=q('id')) { respond(find_by($rows,'id',$id)); }
  if ($email=q('email')) { respond(find_by($rows,'email',$email)); }
  $out=$rows;
  if ($role=q('role')) $out=array_values(array_filter($out, fn($p)=>($p['role']??'')===$role));
  respond($out);
}
$body=json_body();
if ($method==='POST'){
  $found=false; $saved=null;
  foreach($rows as &$r) if((string)$r['id']===(string)($body['id']??'')){ $r=array_merge($r,$body); $found=true; $saved=$r; break; }
  unset($r);
  if(!$found){ if(empty($body['created_at'])) $body['created_at']=date('c'); $rows[]=$body; $saved=$body; }
  write_table('profiles',$rows); respond($saved,201);
}
if ($method==='PUT'){
  foreach($rows as &$r) if((string)$r['id']===(string)($body['id']??'')){
    $safe = $body;
    if (isset($safe['role']) && !in_array($safe['role'], ['customer','admin'], true)) unset($safe['role']);
    $r=array_merge($r,$safe);
    write_table('profiles',$rows);
    if (isset($safe['role'])) {
      $usersFile = data_dir() . '/users.json';
      if (is_file($usersFile)) {
        $users = json_decode((string)file_get_contents($usersFile), true) ?: [];
        foreach ($users as &$u) if ((string)($u['id']??'') === (string)$r['id']) $u['role'] = $safe['role'];
        unset($u);
        $json = json_encode($users, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_INVALID_UTF8_SUBSTITUTE);
        if ($json !== false) file_put_contents($usersFile, $json, LOCK_EX);
      }
    }
    respond($r);
  }
  respond(['error'=>'not found'],404);
}
if ($method==='DELETE'){ $rows=array_values(array_filter($rows,fn($r)=>(string)$r['id']!==(string)($body['id']??''))); write_table('profiles',$rows); respond(['ok'=>true]); }
respond(['error'=>'Method not allowed'],405);
