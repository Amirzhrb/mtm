<?php
require __DIR__ . '/_bootstrap.php';
$dir = data_dir();
$checks = [
  'php' => PHP_VERSION,
  'json' => extension_loaded('json'),
  'fileinfo' => extension_loaded('fileinfo'),
  'curl' => extension_loaded('curl'),
  'mbstring' => extension_loaded('mbstring'),
  'data_writable' => is_writable($dir),
  'uploads_writable' => is_writable(dirname(__DIR__) . '/uploads') || is_writable(dirname(__DIR__)),
  'mode' => 'php-json',
];
respond(['ok' => $checks['json'] && $checks['data_writable'], 'checks' => $checks]);
