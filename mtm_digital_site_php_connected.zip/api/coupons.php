<?php
require __DIR__ . '/_bootstrap.php';
$method = $_SERVER['REQUEST_METHOD'];
$rows = read_table('coupons');
if ($method === 'GET') {
  $code = q('code') ?: q('validate');
  if ($code) {
    $c = null;
    foreach ($rows as $r) if (strtoupper((string)($r['code']??''))===strtoupper((string)$code) && !empty($r['active'])) { $c=$r; break; }
    if (!$c) respond(['error'=>'کد تخفیف معتبر نیست'],404);
    if (!empty($c['expires_at']) && strtotime($c['expires_at']) < time()) respond(['error'=>'کد تخفیف منقضی شده است'],400);
    if (!empty($c['max_uses']) && ($c['used_count']??0) >= $c['max_uses']) respond(['error'=>'ظرفیت استفاده از کد تکمیل شده'],400);
    respond($c);
  }
  usort($rows, fn($a,$b)=>($b['id']??0)<=>($a['id']??0));
  respond($rows);
}
$body = json_body();
if ($method === 'POST') { $body['id']=next_id($rows); $rows[]=$body; write_table('coupons',$rows); respond($body,201);} 
if ($method === 'PUT') { foreach($rows as &$r) if((string)$r['id']===(string)($body['id']??'')){ $r=array_merge($r,$body); write_table('coupons',$rows); respond($r);} respond(['error'=>'not found'],404);} 
if ($method === 'DELETE') { $rows=array_values(array_filter($rows,fn($r)=>(string)$r['id']!==(string)($body['id']??''))); write_table('coupons',$rows); respond(['ok'=>true]); }
respond(['error'=>'Method not allowed'],405);
