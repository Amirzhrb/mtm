<?php
require __DIR__ . '/_bootstrap.php';
$file = basename((string)q('file', ''));
$allowed = ['sitemtm.zip'];
if (!in_array($file, $allowed, true)) respond(['error' => 'فایل درخواستی مجاز نیست.'], 400);
$path = dirname(__DIR__) . '/' . $file;
if (!is_file($path) || !is_readable($path)) respond(['error' => 'بسته دانلود روی سرور موجود نیست.'], 404);
header('Content-Type: application/zip');
header('Content-Length: ' . filesize($path));
header('Content-Disposition: attachment; filename="sitemtm.zip"');
header('Cache-Control: private, no-store, max-age=0');
readfile($path);
exit;
