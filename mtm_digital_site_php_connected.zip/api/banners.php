<?php
require __DIR__ . '/_bootstrap.php';
$method = $_SERVER['REQUEST_METHOD'];
$table = 'banners';
$rows = read_table($table);
if ($method === 'GET') {
  if ($id = q('id')) {
    $row = find_by($rows, 'id', $id);
    respond($row ?: ['error' => 'not found'], $row ? 200 : 404);
  }
  if ($slug = q('slug')) {
    $row = find_by($rows, 'slug', $slug);
    respond($row ?: ['error' => 'not found'], $row ? 200 : 404);
  }
  $out = $rows;
  if (q('active') === 'true') $out = array_values(array_filter($out, fn($b) => !empty($b['active'])));
  if (q('type')) $out = array_values(array_filter($out, fn($b) => ($b['type'] ?? '') === q('type')));
  if (q('product_id')) $out = array_values(array_filter($out, fn($b) => (string)($b['product_id'] ?? '') === (string)q('product_id')));
  if (q('approved') === 'true') $out = array_values(array_filter($out, fn($b) => !isset($b['approved']) || $b['approved']));
  if (q('published') === 'true') $out = array_values(array_filter($out, fn($b) => !isset($b['published']) || $b['published']));
  usort($out, function($a,$b){
    if (isset($a['sort_order']) || isset($b['sort_order'])) return ($a['sort_order'] ?? 0) <=> ($b['sort_order'] ?? 0);
    if (isset($a['created_at']) || isset($b['created_at'])) return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
    return ($a['id'] ?? 0) <=> ($b['id'] ?? 0);
  });
  respond($out);
}
$body = json_body();
if ($method === 'POST') {
  if (empty($body['id'])) $body['id'] = next_id($rows);
  if (empty($body['created_at'])) $body['created_at'] = date('c');
  $rows[] = $body;
  write_table($table, $rows);
  respond($body, 201);
}
if ($method === 'PUT') {
  foreach ($rows as &$r) {
    if ((string)$r['id'] === (string)($body['id'] ?? '')) {
      $r = array_merge($r, $body);
      write_table($table, $rows);
      respond($r);
    }
  }
  respond(['error' => 'not found'], 404);
}
if ($method === 'DELETE') {
  $rows = array_values(array_filter($rows, fn($r) => (string)$r['id'] !== (string)($body['id'] ?? '')));
  write_table($table, $rows);
  respond(['ok' => true]);
}
respond(['error' => 'Method not allowed'], 405);
