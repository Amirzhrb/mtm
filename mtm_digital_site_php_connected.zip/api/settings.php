<?php
require __DIR__ . '/_bootstrap.php';
$defaults = [
  'payment' => ['gateway'=>'zarinpal','gateway_label'=>'زرین‌پال','merchant_id'=>'','api_key'=>'','sandbox'=>true,'active'=>true,'callback_url'=>'/payment/verify','description'=>'پرداخت سفارش MTM Digital'],
  'seo' => ['title'=>'MTM Digital | ام تی ام دیجیتال','description'=>'فروشگاه MTM Digital','keywords'=>'MTM Digital, ام تی ام دیجیتال','og_image'=>'/images/hero-earbuds.jpg','site_name_fa'=>'ام تی ام دیجیتال','site_name_en'=>'MTM Digital'],
  'store' => ['name_fa'=>'ام تی ام دیجیتال','name_en'=>'MTM Digital','tagline'=>'لوازم جانبی و محصولات دیجیتال اصل','phone'=>'09021177804','mobile'=>'09021177804','email'=>'support@mtmdigital.ir','address'=>'منطقه آزاد ماکو','city'=>'قره ضیاالدین','postal_code'=>'','working_hours'=>'همه‌روزه ۹ تا ۲۱','free_shipping_text'=>'ارسال رایگان بالای ۲ میلیون تومان','shipping_cost'=>65000,'free_shipping_min'=>2000000],
  'announcement' => ['enabled'=>true,'text'=>'به ام تی ام دیجیتال خوش آمدید','link'=>'/products?filter=sale','link_text'=>'مشاهده تخفیف‌ها','bg_color'=>'#000000','text_color'=>'#ffffff'],
  'trust_seals' => ['enamad_enabled'=>false,'enamad_code'=>'','samandehi_enabled'=>false,'samandehi_code'=>'','etehadiye_enabled'=>false,'etehadiye_code'=>''],
  'automation' => ['notify_new_order'=>true,'auto_stock'=>true,'smart_recommend'=>true,'low_stock_alert'=>true,'low_stock_threshold'=>10],
  'shipping_methods' => ['methods'=>[
    ['id'=>'standard','name'=>'ارسال عادی','description'=>'پست پیشتاز سراسر کشور','price'=>65000,'eta'=>'۲ تا ۴ روز کاری','active'=>true,'sort_order'=>1],
    ['id'=>'express','name'=>'ارسال سریع','description'=>'تیپاکس / پیک ویژه','price'=>120000,'eta'=>'۱ تا ۲ روز کاری','active'=>true,'sort_order'=>2],
  ]],
];
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'GET') {
  if (q('admin') === '1') require_admin();
  if ($key = q('key')) {
    if (!array_key_exists($key, $defaults)) respond(['error'=>'کلید تنظیمات نامعتبر است'], 404);
    if ($key === 'payment' && q('admin') !== '1') {
      $v = get_setting($key, $defaults[$key]);
      respond(['key'=>$key,'value'=>['gateway'=>$v['gateway'] ?? 'zarinpal','gateway_label'=>$v['gateway_label'] ?? 'زرین‌پال','sandbox'=>!empty($v['sandbox']),'active'=>!empty($v['active']),'configured'=>!empty($v['merchant_id'])]]);
    }
    respond(['key'=>$key,'value'=>get_setting($key, $defaults[$key])]);
  }
  $out = [];
  foreach ($defaults as $k=>$d) {
    if ($k === 'payment') {
      $v = get_setting($k, $d);
      $out[$k] = ['gateway'=>$v['gateway'] ?? 'zarinpal','gateway_label'=>$v['gateway_label'] ?? 'زرین‌پال','sandbox'=>!empty($v['sandbox']),'active'=>!empty($v['active']),'configured'=>!empty($v['merchant_id'])];
    } else {
      $out[$k] = get_setting($k, $d);
    }
  }
  respond($out);
}
if ($method === 'POST' || $method === 'PUT') {
  $body = json_body();
  $key = $body['key'] ?? '';
  $value = $body['value'] ?? null;
  if (!$key || !array_key_exists($key, $defaults) || !is_array($value)) respond(['error'=>'کلید یا مقدار تنظیمات نامعتبر است'],400);
  $existing = get_setting($key, $defaults[$key] ?? []);
  $merged = array_merge($existing, $value);
  if ($key === 'payment' && empty($merged['merchant_id']) && !empty($existing['merchant_id'])) $merged['merchant_id'] = $existing['merchant_id'];
  if ($key === 'payment' && empty($merged['api_key']) && !empty($existing['api_key'])) $merged['api_key'] = $existing['api_key'];
  if ($key === 'store') {
    foreach (['name_fa','name_en','phone','address','free_shipping_text'] as $f) {
      if (isset($merged[$f]) && is_string($merged[$f]) && trim($merged[$f])==='' && isset($defaults['store'][$f])) $merged[$f]=$defaults['store'][$f];
    }
    $merged['shipping_cost'] = (int)($merged['shipping_cost'] ?? 65000);
    $merged['free_shipping_min'] = (int)($merged['free_shipping_min'] ?? 2000000);
  }
  respond(['key'=>$key,'value'=>set_setting($key,$merged),'ok'=>true]);
}
respond(['error'=>'Method not allowed'],405);
