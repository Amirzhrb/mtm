<?php
require __DIR__ . '/_bootstrap.php';

$settings = get_setting('payment', [
  'gateway' => 'zarinpal',
  'gateway_label' => 'زرین‌پال',
  'merchant_id' => '',
  'api_key' => '',
  'sandbox' => true,
  'active' => true,
  'callback_url' => '/payment/verify',
  'description' => 'پرداخت سفارش MTM Digital',
]);

function request_origin() {
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');
  $scheme = $https ? 'https' : 'http';
  $host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
  // Reject malformed Host headers before using them in a payment callback URL.
  if (!preg_match('/^[a-zA-Z0-9.:-]+$/', $host)) $host = 'localhost';
  return $scheme . '://' . $host;
}

function absolute_callback($cb, $orderId) {
  if (!$cb) $cb = '/payment/verify';
  if (strpos($cb, 'http') !== 0) {
    $cb = rtrim(request_origin(), '/') . '/' . ltrim($cb, '/');
  }
  $sep = strpos($cb, '?') !== false ? '&' : '?';
  return $cb . $sep . 'order_id=' . urlencode((string)$orderId);
}

function zarinpal_request($merchant, $amount, $callback, $description, $sandbox, $email = '', $mobile = '') {
  if (!function_exists('curl_init')) return ['ok' => false, 'message' => 'افزونه cURL روی هاست فعال نیست.'];
  $url = $sandbox
    ? 'https://sandbox.zarinpal.com/pg/v4/payment/request.json'
    : 'https://api.zarinpal.com/pg/v4/payment/request.json';
  $payload = json_encode([
    'merchant_id' => $merchant,
    'amount' => (int)$amount,
    'callback_url' => $callback,
    'description' => $description,
    'metadata' => array_filter(['email' => $email ?: null, 'mobile' => $mobile ?: null]),
  ], JSON_UNESCAPED_UNICODE);
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_TIMEOUT => 30,
  ]);
  $raw = curl_exec($ch);
  $err = curl_error($ch);
  curl_close($ch);
  if ($raw === false) return ['ok' => false, 'message' => 'خطا در اتصال به زرین‌پال: ' . $err];
  $data = json_decode($raw, true);
  $code = $data['data']['code'] ?? null;
  $authority = $data['data']['authority'] ?? null;
  if ((int)$code === 100 && $authority) {
    $payBase = $sandbox
      ? 'https://sandbox.zarinpal.com/pg/StartPay/'
      : 'https://www.zarinpal.com/pg/StartPay/';
    return ['ok' => true, 'authority' => $authority, 'payment_url' => $payBase . $authority];
  }
  $msg = $data['errors']['message'] ?? ($data['data']['message'] ?? 'خطای زرین‌پال');
  if (is_array($msg)) $msg = json_encode($msg, JSON_UNESCAPED_UNICODE);
  return ['ok' => false, 'message' => $msg, 'raw' => $data];
}

function zarinpal_verify($merchant, $amount, $authority, $sandbox) {
  if (!function_exists('curl_init')) return ['ok' => false, 'message' => 'افزونه cURL روی هاست فعال نیست.'];
  $url = $sandbox
    ? 'https://sandbox.zarinpal.com/pg/v4/payment/verify.json'
    : 'https://api.zarinpal.com/pg/v4/payment/verify.json';
  $payload = json_encode([
    'merchant_id' => $merchant,
    'amount' => (int)$amount,
    'authority' => $authority,
  ]);
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_TIMEOUT => 30,
  ]);
  $raw = curl_exec($ch);
  curl_close($ch);
  $data = json_decode($raw, true);
  $code = (int)($data['data']['code'] ?? 0);
  if ($code === 100 || $code === 101) {
    return ['ok' => true, 'ref_id' => (string)($data['data']['ref_id'] ?? $data['data']['refId'] ?? '')];
  }
  $msg = $data['errors']['message'] ?? ($data['data']['message'] ?? 'تایید پرداخت ناموفق بود');
  if (is_array($msg)) $msg = json_encode($msg, JSON_UNESCAPED_UNICODE);
  return ['ok' => false, 'message' => $msg];
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
  respond([
    'gateway' => $settings['gateway_label'] ?? $settings['gateway'] ?? 'زرین‌پال',
    'gateway_code' => $settings['gateway'] ?? 'zarinpal',
    'merchant_id' => !empty($settings['merchant_id'])
      ? (substr($settings['merchant_id'], 0, 4) . '****' . substr($settings['merchant_id'], -4))
      : 'تنظیم نشده',
    'status' => !empty($settings['active']) ? 'active' : 'inactive',
    'sandbox' => !empty($settings['sandbox']),
    'callback_url' => $settings['callback_url'] ?? '/payment/verify',
    'configured' => !empty($settings['merchant_id']),
    'real_gateway' => !empty($settings['merchant_id']) && (($settings['gateway'] ?? '') !== 'mock'),
  ]);
}

if ($method === 'POST') {
  $body = json_body();
  if (empty($settings['active'])) respond(['success' => false, 'message' => 'درگاه پرداخت غیرفعال است'], 400);
  $action = $body['action'] ?? '';
  $gateway = strtolower((string)($settings['gateway'] ?? 'zarinpal'));
  if (!in_array($gateway, ['zarinpal', 'mock'], true)) {
    respond(['success' => false, 'message' => 'این درگاه در نسخه فعلی پشتیبانی نمی‌شود.'], 400);
  }
  $hostHeader = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
  $hostOnly = preg_replace('/:\d+$/', '', $hostHeader);
  $isLocalHost = in_array($hostOnly, ['localhost', '127.0.0.1', '[::1]'], true);
  $mockAllowed = $isLocalHost || getenv('MTM_ALLOW_MOCK_PAYMENT') === '1';

  if ($action === 'request') {
    $storeLock = acquire_store_lock();
    $orderId = $body['order_id'] ?? null;
    if (!$orderId) respond(['success' => false, 'message' => 'شناسه سفارش الزامی است'], 400);
    $orders = read_table('orders');
    $order = null;
    foreach ($orders as $o) if ((string)$o['id'] === (string)$orderId) { $order = $o; break; }
    if (!$order) respond(['success' => false, 'message' => 'سفارش یافت نشد'], 404);
    if (($order['payment_method'] ?? 'online') !== 'online') respond(['success' => false, 'message' => 'این سفارش برای پرداخت آنلاین ثبت نشده است.'], 400);
    if (($order['payment_status'] ?? '') === 'paid') respond(['success' => false, 'message' => 'این سفارش قبلاً پرداخت شده است.'], 409);

    // Never trust a total supplied by the browser; use the saved server-side order total.
    $amount = (int)($order['total'] ?? 0);
    if ($amount < 1000) respond(['success' => false, 'message' => 'مبلغ پرداخت نامعتبر است'], 400);

    $useMock = ($gateway === 'mock' && $mockAllowed);
    if ($gateway === 'mock' && !$mockAllowed) {
      respond(['success' => false, 'message' => 'شبیه‌ساز پرداخت فقط در محیط توسعه محلی فعال است.'], 403);
    }

    if ($useMock) {
      $auth = 'A' . strtoupper(base_convert((string)time(), 10, 36)) . strtoupper(substr(md5(uniqid('', true)), 0, 6));
      foreach ($orders as &$o) {
        if ((string)$o['id'] === (string)$orderId) {
          $o['payment_authority'] = $auth;
          $o['payment_status'] = 'pending';
          $o['payment_method'] = 'online';
        }
      }
      unset($o);
      write_table('orders', $orders);
      $cb = $settings['callback_url'] ?? '/payment/verify';
      $sep = strpos($cb, '?') !== false ? '&' : '?';
      respond([
        'success' => true,
        'authority' => $auth,
        'amount' => $amount,
        'redirect' => true,
        'payment_url' => $cb . $sep . 'Authority=' . $auth . '&Status=OK&order_id=' . $orderId,
        'message' => 'درخواست پرداخت آزمایشی ایجاد شد',
        'sandbox' => true,
      ]);
    }

    if (empty($settings['merchant_id'])) {
      respond(['success' => false, 'message' => 'مرچنت‌آیدی معتبر زرین‌پال در پنل مدیریت ثبت نشده است. برای تست از شبیه‌ساز فقط در محیط محلی استفاده کنید.'], 400);
    }

    $callback = absolute_callback($settings['callback_url'] ?? '/payment/verify', $orderId);
    $zp = zarinpal_request(
      $settings['merchant_id'],
      $amount,
      $callback,
      $settings['description'] ?? ('سفارش ' . ($order['order_number'] ?? '')),
      !empty($settings['sandbox']),
      $order['customer_email'] ?? '',
      $order['customer_phone'] ?? ''
    );
    if (empty($zp['ok'])) respond(['success' => false, 'message' => $zp['message'] ?? 'خطای زرین‌پال'], 400);

    foreach ($orders as &$o) {
      if ((string)$o['id'] === (string)$orderId) {
        $o['payment_authority'] = $zp['authority'];
        $o['payment_status'] = 'pending';
        $o['payment_method'] = 'online';
      }
    }
    unset($o);
    write_table('orders', $orders);

    respond([
      'success' => true,
      'authority' => $zp['authority'],
      'amount' => $amount,
      'redirect' => true,
      'payment_url' => $zp['payment_url'],
      'gateway' => $settings['gateway_label'] ?? 'زرین‌پال',
      'sandbox' => !empty($settings['sandbox']),
      'message' => 'در حال انتقال به درگاه پرداخت...',
    ]);
  }

  if ($action === 'verify') {
    $storeLock = acquire_store_lock();
    $orderId = $body['order_id'] ?? null;
    if (!$orderId) respond(['success' => false, 'message' => 'شناسه سفارش الزامی است'], 400);
    $orders = read_table('orders');
    $idx = null;
    foreach ($orders as $i => $o) if ((string)$o['id'] === (string)$orderId) { $idx = $i; break; }
    if ($idx === null) respond(['success' => false, 'message' => 'سفارش یافت نشد'], 404);
    $order = $orders[$idx];

    $auth = (string)($body['authority'] ?? ($body['Authority'] ?? ''));
    $storedAuthority = (string)($order['payment_authority'] ?? '');
    if ($auth === '' || $storedAuthority === '' || !hash_equals($storedAuthority, $auth)) {
      respond(['success' => false, 'message' => 'شناسه پرداخت معتبر نیست.'], 403);
    }
    if (($order['payment_status'] ?? '') === 'paid') {
      respond(['success' => true, 'order' => $order, 'message' => 'این سفارش قبلاً پرداخت شده است']);
    }
    $status = strtoupper((string)($body['Status'] ?? ($body['status'] ?? 'NOK')));
    $useMock = ($gateway === 'mock' && $mockAllowed);
    if ($gateway === 'mock' && !$mockAllowed) {
      respond(['success' => false, 'message' => 'شبیه‌ساز پرداخت فقط در محیط توسعه محلی فعال است.'], 403);
    }

    if ($status === 'NOK' || $status === 'FAILED') {
      $orders[$idx]['payment_status'] = 'failed';
      write_table('orders', $orders);
      respond(['success' => false, 'message' => 'پرداخت توسط کاربر لغو شد', 'order' => $orders[$idx]], 400);
    }

    $ref = 'REF-' . strtoupper(base_convert((string)time(), 10, 36));

    if (!$useMock && !empty($settings['merchant_id'])) {
      $vr = zarinpal_verify($settings['merchant_id'], $order['total'] ?? 0, $auth, !empty($settings['sandbox']));
      if (empty($vr['ok'])) {
        $orders[$idx]['payment_status'] = 'failed';
        write_table('orders', $orders);
        respond(['success' => false, 'message' => $vr['message'] ?? 'تایید ناموفق', 'order' => $orders[$idx]], 400);
      }
      if (!empty($vr['ref_id'])) $ref = $vr['ref_id'];
    } elseif (!$useMock) {
      respond(['success' => false, 'message' => 'تنظیمات درگاه پرداخت کامل نیست.'], 400);
    }

    $orders[$idx]['payment_status'] = 'paid';
    $orders[$idx]['status'] = 'processing';
    $orders[$idx]['payment_ref'] = $ref;
    $orders[$idx]['payment_authority'] = $auth;
    write_table('orders', $orders);

    $notes = read_table('notifications');
    $notes[] = [
      'id' => next_id($notes),
      'title' => 'پرداخت موفق',
      'message' => 'پرداخت سفارش ' . ($orders[$idx]['order_number'] ?? '') . ' تایید شد — ' . $ref,
      'type' => 'payment',
      'read' => false,
      'created_at' => date('c'),
    ];
    write_table('notifications', $notes);

    respond([
      'success' => true,
      'order' => $orders[$idx],
      'gateway' => $settings['gateway_label'] ?? 'زرین‌پال',
      'message' => 'پرداخت با موفقیت تایید و سفارش ثبت شد',
    ]);
  }

  respond(['error' => 'action نامعتبر است'], 400);
}

respond(['error' => 'Method not allowed'], 405);
